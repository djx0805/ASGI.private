#define VMA_IMPLEMENTATION
#include "VmaUsage.h"
