var searchData=
[
  ['vmaallocation',['VmaAllocation',['../struct_vma_allocation.html',1,'']]],
  ['vmaallocationcreateinfo',['VmaAllocationCreateInfo',['../struct_vma_allocation_create_info.html',1,'']]],
  ['vmaallocationinfo',['VmaAllocationInfo',['../struct_vma_allocation_info.html',1,'']]],
  ['vmaallocator',['VmaAllocator',['../struct_vma_allocator.html',1,'']]],
  ['vmaallocatorcreateinfo',['VmaAllocatorCreateInfo',['../struct_vma_allocator_create_info.html',1,'']]],
  ['vmadefragmentationinfo',['VmaDefragmentationInfo',['../struct_vma_defragmentation_info.html',1,'']]],
  ['vmadefragmentationstats',['VmaDefragmentationStats',['../struct_vma_defragmentation_stats.html',1,'']]],
  ['vmadevicememorycallbacks',['VmaDeviceMemoryCallbacks',['../struct_vma_device_memory_callbacks.html',1,'']]],
  ['vmapool',['VmaPool',['../struct_vma_pool.html',1,'']]],
  ['vmapoolcreateinfo',['VmaPoolCreateInfo',['../struct_vma_pool_create_info.html',1,'']]],
  ['vmapoolstats',['VmaPoolStats',['../struct_vma_pool_stats.html',1,'']]],
  ['vmarecordsettings',['VmaRecordSettings',['../struct_vma_record_settings.html',1,'']]],
  ['vmastatinfo',['VmaStatInfo',['../struct_vma_stat_info.html',1,'']]],
  ['vmastats',['VmaStats',['../struct_vma_stats.html',1,'']]],
  ['vmavulkanfunctions',['VmaVulkanFunctions',['../struct_vma_vulkan_functions.html',1,'']]]
];
