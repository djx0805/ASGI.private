var searchData=
[
  ['general_20considerations',['General considerations',['../general_considerations.html',1,'index']]]
];
