var searchData=
[
  ['vulkan_20memory_20allocator',['Vulkan Memory Allocator',['../index.html',1,'']]],
  ['vk_5fkhr_5fdedicated_5fallocation',['VK_KHR_dedicated_allocation',['../vk_khr_dedicated_allocation.html',1,'index']]]
];
